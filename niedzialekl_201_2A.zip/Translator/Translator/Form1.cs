﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Translator {
	public partial class Form1 : Form {
		public Form1() {
			InitializeComponent();
		}

		OpenFileDialog open = new OpenFileDialog();
		List<data> arr = new List<data>(); 

		private void button1_Click(object sender, EventArgs e) {
			
		}

		private void loadToolStripMenuItem_Click(object sender, EventArgs e) {
			if(open.ShowDialog() == System.Windows.Forms.DialogResult.OK)  
			{  
				System.IO.StreamReader sr = new   
					System.IO.StreamReader(open.FileName);

				
				while (!sr.EndOfStream)
				{
					var line = sr.ReadLine();
					if(line.Equals(""))
						continue;
					var lineWords = line.Split(' ');
					arr.Add(new data(lineWords[0], lineWords[1]));;
					listView1.Items.Add(new ListViewItem(new [] {lineWords[0], lineWords[1]}));
				}

				sr.Close();  
			} 
		}

		private void exportToolStripMenuItem_Click(object sender, EventArgs e) {
			if(open.ShowDialog() == System.Windows.Forms.DialogResult.OK)  
			{  
				System.IO.StreamWriter sr = new   
					System.IO.StreamWriter(open.FileName);


				for (int i = 0; i < arr.Count; i++) {
					sr.WriteLine(arr[i].eng + " " + arr[i].pol);
				}

				sr.Close();  
			} 
		}
	}

	public class data {

		public data(string pol, string eng) {
			this.pol = pol;
			this.eng = eng;
		}

		public string pol;
		public string eng;
	}
}
