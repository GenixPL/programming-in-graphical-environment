﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace niedzialekl_201_3A {
	public partial class Form1 : Form {

		private bool isBrushActive = false;
		private bool isDrawing = false;
		private Pen pen;
		private Bitmap bmp;
		private Point? prevPoint;

		public Form1() {
			InitializeComponent();
			pen = new Pen(Color.Black, 1);
			addColors();
		}

		public void addColors() {
			KnownColor[] values = (KnownColor[]) Enum.GetValues(typeof(KnownColor));
			foreach (var color in values) {
				Button newBut = new Button();
				newBut.BackColor = Color.FromKnownColor(color);
				newBut.Size = new Size(25,25);
				newBut.Click += (object sender, EventArgs e) => { pen = new Pen(newBut.BackColor); };
				flowLayoutPanel1.Controls.Add(newBut);
			}
		}

		//BRUSH BUTTON
		private void toolStripButton2_Click(object sender, EventArgs e) {
			isBrushActive = !isBrushActive;
			toolStripButton2.Checked = isBrushActive;
		}

		//MOUSE DOWN
		private void pictureBox1_MouseDown(object sender, MouseEventArgs e) {
			if (e.Button == MouseButtons.Right)
				isDrawing = false;
			else
				isDrawing = true;

			prevPoint = e.Location;
		}

		//MOUSE UP
		private void pictureBox1_MouseUp(object sender, MouseEventArgs e) {
			isDrawing = false;
		}

		//MOUSE MOVE
		private void pictureBox1_MouseMove(object sender, MouseEventArgs e) {
			if (isBrushActive && isDrawing) {
				if (prevPoint != null) {
					if (pictureBox1.Image == null) {
						bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
						using (Graphics g = Graphics.FromImage(bmp)) {
							g.Clear(Color.White);
						}

						pictureBox1.Image = bmp;
					}

					using (Graphics g = Graphics.FromImage(pictureBox1.Image)) {
						g.DrawLine(pen, prevPoint.Value, e.Location);
					}

					pictureBox1.Invalidate();
					prevPoint = e.Location;
				}
			}
		}

		//RESIZE
		private void Form1_ResizeEnd(object sender, EventArgs e) {
			
		}

		private void Form1_SizeChanged(object sender, EventArgs e) {
			if (bmp != null) {
				Bitmap temp = bmp;
				bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
				using (Graphics grfx = Graphics.FromImage(bmp)) {
					grfx.DrawImage(temp, 0, 0);
				}

				pictureBox1.Image = bmp;
				pictureBox1.Invalidate();
			}

			flowLayoutPanel1.Refresh();
		}

		private void pictureBox1_SizeChanged(object sender, EventArgs e) {
		}
	}
}
