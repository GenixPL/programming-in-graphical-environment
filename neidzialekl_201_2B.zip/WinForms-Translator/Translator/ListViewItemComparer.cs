﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Translator {
	class ListViewItemComparer : IComparer {
		private int col;
		private SortOrder sortOrder { get; set; }

		public ListViewItemComparer(int column, SortOrder sortOrder) {
			col = column;
			this.sortOrder = sortOrder;
		}

		public int Compare(object x, object y) {
			int result = String.Compare(((ListViewItem) x).SubItems[col].Text, ((ListViewItem) y).SubItems[col].Text);

			if (sortOrder == SortOrder.Ascending)
				return result;
			else
				return result * -1;
		}
	}
}
