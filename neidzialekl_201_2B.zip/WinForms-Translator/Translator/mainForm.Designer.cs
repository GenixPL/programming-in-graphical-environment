﻿namespace Translator {
	partial class mainForm {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.leftTable = new System.Windows.Forms.TableLayoutPanel();
			this.addWord_but = new System.Windows.Forms.Button();
			this.listView1 = new System.Windows.Forms.ListView();
			this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
			this.rightTable = new System.Windows.Forms.TableLayoutPanel();
			this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
			this.richText_Top = new System.Windows.Forms.RichTextBox();
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.boldButton = new System.Windows.Forms.ToolStripButton();
			this.italicButton = new System.Windows.Forms.ToolStripButton();
			this.underlineButton = new System.Windows.Forms.ToolStripButton();
			this.textColor_but = new System.Windows.Forms.ToolStripButton();
			this.backColor_But = new System.Windows.Forms.ToolStripButton();
			this.fontsComboBox = new System.Windows.Forms.ToolStripComboBox();
			this.richText_Bottom = new System.Windows.Forms.RichTextBox();
			this.translate_but = new System.Windows.Forms.Button();
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.importToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.exportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.mainTable = new System.Windows.Forms.TableLayoutPanel();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.leftTable.SuspendLayout();
			this.rightTable.SuspendLayout();
			this.toolStripContainer1.ContentPanel.SuspendLayout();
			this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
			this.toolStripContainer1.SuspendLayout();
			this.toolStrip1.SuspendLayout();
			this.menuStrip1.SuspendLayout();
			this.mainTable.SuspendLayout();
			this.SuspendLayout();
			// 
			// splitContainer1
			// 
			this.splitContainer1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
			this.splitContainer1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.splitContainer1.Location = new System.Drawing.Point(5, 35);
			this.splitContainer1.Margin = new System.Windows.Forms.Padding(5);
			this.splitContainer1.Name = "splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Control;
			this.splitContainer1.Panel1.Controls.Add(this.leftTable);
			this.splitContainer1.Panel1MinSize = 200;
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.rightTable);
			this.splitContainer1.Panel2MinSize = 100;
			this.splitContainer1.Size = new System.Drawing.Size(974, 414);
			this.splitContainer1.SplitterDistance = 258;
			this.splitContainer1.SplitterWidth = 10;
			this.splitContainer1.TabIndex = 1;
			this.splitContainer1.SplitterMoved += new System.Windows.Forms.SplitterEventHandler(this.splitContainer1_SplitterMoved_1);
			// 
			// leftTable
			// 
			this.leftTable.BackColor = System.Drawing.SystemColors.Control;
			this.leftTable.ColumnCount = 1;
			this.leftTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.leftTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.leftTable.Controls.Add(this.addWord_but, 0, 1);
			this.leftTable.Controls.Add(this.listView1, 0, 0);
			this.leftTable.Dock = System.Windows.Forms.DockStyle.Fill;
			this.leftTable.Location = new System.Drawing.Point(0, 0);
			this.leftTable.MinimumSize = new System.Drawing.Size(200, 0);
			this.leftTable.Name = "leftTable";
			this.leftTable.RowCount = 2;
			this.leftTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 89.17647F));
			this.leftTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.82353F));
			this.leftTable.Size = new System.Drawing.Size(258, 414);
			this.leftTable.TabIndex = 0;
			// 
			// addWord_but
			// 
			this.addWord_but.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.addWord_but.Location = new System.Drawing.Point(72, 380);
			this.addWord_but.Name = "addWord_but";
			this.addWord_but.Size = new System.Drawing.Size(114, 23);
			this.addWord_but.TabIndex = 1;
			this.addWord_but.Text = "Add new word";
			this.addWord_but.UseVisualStyleBackColor = true;
			this.addWord_but.Click += new System.EventHandler(this.addWord_but_Click);
			// 
			// listView1
			// 
			this.listView1.AllowDrop = true;
			this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
			this.listView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.listView1.FullRowSelect = true;
			this.listView1.GridLines = true;
			this.listView1.Location = new System.Drawing.Point(3, 3);
			this.listView1.Name = "listView1";
			this.listView1.Size = new System.Drawing.Size(252, 363);
			this.listView1.TabIndex = 0;
			this.listView1.UseCompatibleStateImageBehavior = false;
			this.listView1.View = System.Windows.Forms.View.Details;
			this.listView1.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.listView1_ColumnClick);
			this.listView1.DragDrop += new System.Windows.Forms.DragEventHandler(this.listView1_DragDrop);
			this.listView1.DragEnter += new System.Windows.Forms.DragEventHandler(this.listView1_DragEnter);
			this.listView1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listView1_KeyDown);
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "English";
			this.columnHeader1.Width = 127;
			// 
			// columnHeader2
			// 
			this.columnHeader2.Text = "Polish";
			this.columnHeader2.Width = 123;
			// 
			// rightTable
			// 
			this.rightTable.BackColor = System.Drawing.SystemColors.Control;
			this.rightTable.ColumnCount = 1;
			this.rightTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.rightTable.Controls.Add(this.toolStripContainer1, 0, 0);
			this.rightTable.Controls.Add(this.richText_Bottom, 0, 2);
			this.rightTable.Controls.Add(this.translate_but, 0, 1);
			this.rightTable.Dock = System.Windows.Forms.DockStyle.Fill;
			this.rightTable.Location = new System.Drawing.Point(0, 0);
			this.rightTable.Name = "rightTable";
			this.rightTable.RowCount = 3;
			this.rightTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 55F));
			this.rightTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
			this.rightTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 45F));
			this.rightTable.Size = new System.Drawing.Size(706, 414);
			this.rightTable.TabIndex = 0;
			// 
			// toolStripContainer1
			// 
			// 
			// toolStripContainer1.ContentPanel
			// 
			this.toolStripContainer1.ContentPanel.Controls.Add(this.richText_Top);
			this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(700, 166);
			this.toolStripContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.toolStripContainer1.LeftToolStripPanelVisible = false;
			this.toolStripContainer1.Location = new System.Drawing.Point(3, 3);
			this.toolStripContainer1.Name = "toolStripContainer1";
			this.toolStripContainer1.RightToolStripPanelVisible = false;
			this.toolStripContainer1.Size = new System.Drawing.Size(700, 194);
			this.toolStripContainer1.TabIndex = 2;
			this.toolStripContainer1.Text = "toolStripContainer1";
			// 
			// toolStripContainer1.TopToolStripPanel
			// 
			this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
			// 
			// richText_Top
			// 
			this.richText_Top.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richText_Top.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.richText_Top.Location = new System.Drawing.Point(0, 0);
			this.richText_Top.Name = "richText_Top";
			this.richText_Top.Size = new System.Drawing.Size(700, 166);
			this.richText_Top.TabIndex = 0;
			this.richText_Top.Text = "";
			// 
			// toolStrip1
			// 
			this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
			this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.boldButton,
            this.italicButton,
            this.underlineButton,
            this.textColor_but,
            this.backColor_But,
            this.fontsComboBox});
			this.toolStrip1.Location = new System.Drawing.Point(3, 0);
			this.toolStrip1.Name = "toolStrip1";
			this.toolStrip1.Size = new System.Drawing.Size(255, 28);
			this.toolStrip1.TabIndex = 0;
			// 
			// boldButton
			// 
			this.boldButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.boldButton.Image = global::Translator.Properties.Resources.Bold;
			this.boldButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.boldButton.Name = "boldButton";
			this.boldButton.Size = new System.Drawing.Size(24, 25);
			this.boldButton.Text = "bold";
			this.boldButton.Click += new System.EventHandler(this.boldButton_Click);
			// 
			// italicButton
			// 
			this.italicButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.italicButton.Image = global::Translator.Properties.Resources.Italic;
			this.italicButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.italicButton.Name = "italicButton";
			this.italicButton.Size = new System.Drawing.Size(24, 25);
			this.italicButton.Text = "italic";
			this.italicButton.Click += new System.EventHandler(this.italicButton_Click);
			// 
			// underlineButton
			// 
			this.underlineButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.underlineButton.Image = global::Translator.Properties.Resources.Underline;
			this.underlineButton.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.underlineButton.Name = "underlineButton";
			this.underlineButton.Size = new System.Drawing.Size(24, 25);
			this.underlineButton.Text = "underline";
			this.underlineButton.Click += new System.EventHandler(this.underlineButton_Click);
			// 
			// textColor_but
			// 
			this.textColor_but.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.textColor_but.Image = global::Translator.Properties.Resources.FontColor;
			this.textColor_but.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.textColor_but.Name = "textColor_but";
			this.textColor_but.Size = new System.Drawing.Size(24, 25);
			this.textColor_but.Text = "textColor";
			this.textColor_but.Click += new System.EventHandler(this.textColor_but_Click);
			// 
			// backColor_But
			// 
			this.backColor_But.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.backColor_But.Image = global::Translator.Properties.Resources.BackColor;
			this.backColor_But.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.backColor_But.Name = "backColor_But";
			this.backColor_But.Size = new System.Drawing.Size(24, 25);
			this.backColor_But.Text = "backColor";
			this.backColor_But.Click += new System.EventHandler(this.backColor_But_Click);
			// 
			// fontsComboBox
			// 
			this.fontsComboBox.Name = "fontsComboBox";
			this.fontsComboBox.Size = new System.Drawing.Size(121, 28);
			this.fontsComboBox.SelectedIndexChanged += new System.EventHandler(this.fontsComboBox_SelectedIndexChanged);
			// 
			// richText_Bottom
			// 
			this.richText_Bottom.Dock = System.Windows.Forms.DockStyle.Fill;
			this.richText_Bottom.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.richText_Bottom.Location = new System.Drawing.Point(3, 253);
			this.richText_Bottom.Name = "richText_Bottom";
			this.richText_Bottom.ReadOnly = true;
			this.richText_Bottom.Size = new System.Drawing.Size(700, 158);
			this.richText_Bottom.TabIndex = 1;
			this.richText_Bottom.Text = "";
			this.richText_Bottom.MouseDown += new System.Windows.Forms.MouseEventHandler(this.setWord_richText_MouseDown);
			// 
			// translate_but
			// 
			this.translate_but.Anchor = System.Windows.Forms.AnchorStyles.None;
			this.translate_but.AutoSize = true;
			this.translate_but.Location = new System.Drawing.Point(312, 211);
			this.translate_but.Name = "translate_but";
			this.translate_but.Size = new System.Drawing.Size(81, 27);
			this.translate_but.TabIndex = 2;
			this.translate_but.Text = "Translate!";
			this.translate_but.UseVisualStyleBackColor = true;
			this.translate_but.Click += new System.EventHandler(this.translate_but_Click);
			// 
			// menuStrip1
			// 
			this.menuStrip1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(984, 30);
			this.menuStrip1.TabIndex = 1;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// fileToolStripMenuItem
			// 
			this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.importToolStripMenuItem,
            this.exportToolStripMenuItem});
			this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
			this.fileToolStripMenuItem.Size = new System.Drawing.Size(44, 24);
			this.fileToolStripMenuItem.Text = "File";
			// 
			// importToolStripMenuItem
			// 
			this.importToolStripMenuItem.Name = "importToolStripMenuItem";
			this.importToolStripMenuItem.Size = new System.Drawing.Size(129, 26);
			this.importToolStripMenuItem.Text = "Import";
			this.importToolStripMenuItem.Click += new System.EventHandler(this.loadToolStripMenuItem_Click);
			// 
			// exportToolStripMenuItem
			// 
			this.exportToolStripMenuItem.Name = "exportToolStripMenuItem";
			this.exportToolStripMenuItem.Size = new System.Drawing.Size(129, 26);
			this.exportToolStripMenuItem.Text = "Export";
			this.exportToolStripMenuItem.Click += new System.EventHandler(this.exportToolStripMenuItem_Click);
			// 
			// mainTable
			// 
			this.mainTable.ColumnCount = 1;
			this.mainTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.mainTable.Controls.Add(this.menuStrip1, 0, 0);
			this.mainTable.Controls.Add(this.splitContainer1, 0, 1);
			this.mainTable.Dock = System.Windows.Forms.DockStyle.Fill;
			this.mainTable.Location = new System.Drawing.Point(0, 0);
			this.mainTable.Name = "mainTable";
			this.mainTable.RowCount = 2;
			this.mainTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
			this.mainTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.mainTable.Size = new System.Drawing.Size(984, 454);
			this.mainTable.TabIndex = 1;
			// 
			// mainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(984, 454);
			this.Controls.Add(this.mainTable);
			this.MainMenuStrip = this.menuStrip1;
			this.MinimumSize = new System.Drawing.Size(500, 400);
			this.Name = "mainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "mainForm";
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
			this.splitContainer1.ResumeLayout(false);
			this.leftTable.ResumeLayout(false);
			this.rightTable.ResumeLayout(false);
			this.rightTable.PerformLayout();
			this.toolStripContainer1.ContentPanel.ResumeLayout(false);
			this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
			this.toolStripContainer1.TopToolStripPanel.PerformLayout();
			this.toolStripContainer1.ResumeLayout(false);
			this.toolStripContainer1.PerformLayout();
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.mainTable.ResumeLayout(false);
			this.mainTable.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.TableLayoutPanel rightTable;
		private System.Windows.Forms.RichTextBox richText_Top;
		private System.Windows.Forms.RichTextBox richText_Bottom;
		private System.Windows.Forms.Button translate_but;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ColumnHeader columnHeader2;
		private System.Windows.Forms.Button addWord_but;
		private System.Windows.Forms.TableLayoutPanel leftTable;
		private System.Windows.Forms.ToolStripContainer toolStripContainer1;
		private System.Windows.Forms.ToolStrip toolStrip1;
		private System.Windows.Forms.ToolStripButton boldButton;
		private System.Windows.Forms.ToolStripButton italicButton;
		private System.Windows.Forms.ToolStripButton underlineButton;
		private System.Windows.Forms.ToolStripButton textColor_but;
		private System.Windows.Forms.ToolStripButton backColor_But;
		private System.Windows.Forms.ToolStripComboBox fontsComboBox;
		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem importToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem exportToolStripMenuItem;
		private System.Windows.Forms.TableLayoutPanel mainTable;
	}
}

