﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Translator {
	public partial class validationErrForm : Form {
		public validationErrForm() {
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e) {
			Owner.Enabled = true;
			this.Close();
		}

		private void validationErrForm_FormClosing(object sender, FormClosingEventArgs e) {
			Owner.Enabled = true;
		}
	}
}
