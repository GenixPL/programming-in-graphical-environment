﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Translator {
	public partial class mainForm : Form {

		public mainForm() {
			InitializeComponent();

			foreach (FontFamily ff in FontFamily.Families)
			{
				if(ff.IsStyleAvailable(FontStyle.Regular))
					fontsComboBox.Items.Add(ff.Name);                                             
			}

			fontsComboBox.SelectedItem = "Calibri";
		}

		//FIELDS
		private List<data> arrOfWords = new List<data>();
		private List<string> fonts = new List<string>();
		private ColorDialog colorDialog = new ColorDialog();
		private static bool isSortedAsc = true;
		private static bool isBolded = false;
		private static bool isItalic = false;
		private static bool isUnderline = false;



		//IMPORT
		private void loadToolStripMenuItem_Click(object sender, EventArgs e) {
			OpenFileDialog openDialog = new OpenFileDialog();

			if(openDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)  
			{  
				System.IO.StreamReader sr = new   
					System.IO.StreamReader(openDialog.FileName);

				listView1.Items.Clear();
				arrOfWords.Clear();

				//column headers
				var line = sr.ReadLine();
				var lineWords = line.Split(' ');
				while (!onlyLetters(lineWords[0], lineWords[1])) {
					line = sr.ReadLine();
					lineWords = line.Split(' ');
				}
				listView1.Columns[0].Text = lineWords[0];
				listView1.Columns[1].Text = lineWords[1];
				arrOfWords.Add(new data(lineWords[0], lineWords[1]));

				//listView
				while (!sr.EndOfStream)
				{
					line = sr.ReadLine();
					lineWords = line.Split(' ');
					while (!onlyLetters(lineWords[0], lineWords[1])) {
						line = sr.ReadLine();
						lineWords = line.Split(' ');
					}

					if (lineWords.Length != 2 || lineWords[0] == "" || lineWords[1]=="")
						continue;

					arrOfWords.Add(new data(lineWords[0], lineWords[1]));
					listView1.Items.Add(new ListViewItem(new [] {lineWords[0], lineWords[1]}));
				}

				sr.Close();  
			} 
		}

		//EXPORT
		private void exportToolStripMenuItem_Click(object sender, EventArgs e) {
			SaveFileDialog saveDialog = new SaveFileDialog();

			if(saveDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)  
			{  
				System.IO.StreamWriter sr = new   
					System.IO.StreamWriter(saveDialog.FileName);


				for (int i = 0; i < arrOfWords.Count; i++) {
					sr.WriteLine(arrOfWords[i].word2 + " " + arrOfWords[i].word1);
				}

				sr.Close();  
			} 
		}

		//ADDITIONAL METHODS
		bool onlyLetters(string word1, string word2) {
			foreach (var CHAR in word1) {
				if (!Char.IsLetter(CHAR))
					return false;
			}

			foreach (var CHAR in word2) {
				if (!Char.IsLetter(CHAR))
					return false;
			}

			return true;
		}

		//TRANSLATE BUTTON
		private void translate_but_Click(object sender, EventArgs e) {
			richText_Bottom.Text = "";
			string[] dataFromRichText = richText_Top.Text.Split(new char[]{' ', '\n'});

			for (int i = 0; i < dataFromRichText.Length; i++) {
				bool changed = false;
				string toTranslate = dataFromRichText[i];
				toTranslate = toTranslate.ToLower();

				foreach (var data in arrOfWords) {
					if (toTranslate.Equals(data.word1.ToLower())) {
						richText_Bottom.SelectionStart = richText_Bottom.TextLength;
						richText_Bottom.SelectionLength = toTranslate.Length;

						richText_Bottom.SelectionColor = Color.Black;
						richText_Bottom.AppendText(data.word2.ToLower() + " ");
						changed = true;
					}
				}

				if (!changed) {
					richText_Bottom.SelectionStart = richText_Bottom.TextLength;
					richText_Bottom.SelectionLength = toTranslate.Length;

					richText_Bottom.SelectionColor = Color.Red;
					richText_Bottom.AppendText(toTranslate + " ");
				}
			}
		}

		//MOVING SPLITER
		private void splitContainer1_SplitterMoved_1(object sender, SplitterEventArgs e) {
			listView1.Columns[0].Width = listView1.Width / 2;
			listView1.Columns[1].Width = listView1.Width / 2 - 4;
		}

		//DELETING FROM LIST VIEW
		private void listView1_KeyDown(object sender, KeyEventArgs e)
		{
			if (Keys.Delete == e.KeyCode)
			{
				foreach (ListViewItem listViewItem in ((ListView)sender).SelectedItems)
				{
					listViewItem.Remove();
				}
			}
		}

		//COLUMN SORTING
		private void listView1_ColumnClick(object sender, ColumnClickEventArgs e) {
		
			if (isSortedAsc) {
				listView1.ListViewItemSorter = new ListViewItemComparer(e.Column, SortOrder.Ascending);
				isSortedAsc = false;
			} else {
				listView1.ListViewItemSorter = new ListViewItemComparer(e.Column, SortOrder.Descending);
				isSortedAsc = true;
			}

			listView1.Sort();
		}

		//DISPLAY ADD WORD WINDOW
		private void addWord_but_Click(object sender, EventArgs e) {
			addWordForm childForm = new addWordForm(this);
			childForm.Owner = this;
			childForm.DisactivateOwner();

			childForm.Location = new Point(
				(this.Location.X + this.Width / 2) - (childForm.Width / 2), 
				(this.Location.Y + this.Height / 2) - (childForm.Height / 2));

			childForm.MaximizeBox = false;
			childForm.MinimizeBox = false;
			childForm.FormBorderStyle = FormBorderStyle.FixedDialog;

			childForm.setLabels(listView1.Columns[0].Text, listView1.Columns[1].Text);

			childForm.Show();
		}

		//ADD WORDS TO LIST VIEW (FOR OTHER FORMS)
		public void addWords(string word1, string word2) {
			arrOfWords.Add(new data(word1, word2));
			listView1.Items.Add(new ListViewItem(new [] {word1, word2}));
		}

		//CONTEXT MENU FOR BOTTOM RICH_TEXT
		private void setWord_richText_MouseDown(object sender, MouseEventArgs e) {
			if (e.Button == MouseButtons.Right) {
				string[] dataFromRichText = richText_Bottom.Text.Split(new char[]{' ', '\n'});
				string toGive = "";

				for (int i = dataFromRichText.Length - 1; i >= 0; i--) {
					bool exists = false;

					if(dataFromRichText[i].Equals(""))
						continue;

					//if exists in translations
					foreach (var data in arrOfWords) {
						if (data.word2.Equals(dataFromRichText[i]))
							exists = true;
					}

					if (!exists) {
						toGive = dataFromRichText[i];
						break;
					}
				}

				if (!toGive.Equals("")) {
					ContextMenu cm = new ContextMenu();
					cm.MenuItems.Add("Add " + toGive, specialAddWordForm);

					richText_Bottom.ContextMenu = cm;
				}
			}
		}

		//SHOW ADD WORD FORM WITH GIVEN TEXT
		private void specialAddWordForm(Object sender, System.EventArgs e) {
			string[] dataFromRichText = richText_Bottom.Text.Split(new char[]{' ', '\n'});
			string toGive = "";

			for (int i = dataFromRichText.Length - 1; i >= 0; i--) {
				bool exists = false;

				if(dataFromRichText[i].Equals(""))
					continue;

				//if exists in translations
				foreach (var data in arrOfWords) {
					if (data.word2.Equals(dataFromRichText[i]))
						exists = true;
				}

				if (!exists) {
					toGive = dataFromRichText[i];
					break;
				}
			}
			addWordForm childForm = new addWordForm(this, toGive);
			childForm.Owner = this;
			childForm.DisactivateOwner();

			childForm.Location = new Point(
				(this.Location.X + this.Width / 2) - (childForm.Width / 2), 
				(this.Location.Y + this.Height / 2) - (childForm.Height / 2));

			childForm.MaximizeBox = false;
			childForm.MinimizeBox = false;
			childForm.FormBorderStyle = FormBorderStyle.FixedDialog;

			childForm.setLabels(listView1.Columns[0].Text, listView1.Columns[1].Text);

			childForm.Show();
		}
		
		//BOLD BUTTON
		private void boldButton_Click(object sender, EventArgs e) {
			isBolded = !isBolded;
			boldButton.Checked = isBolded;
			repaintTextBox();
		}

		//CREATE PROPER FONT
		private void repaintTextBox() {
			FontStyle style = new FontStyle();

			if (isBolded)
				style |= FontStyle.Bold;

			if (isItalic)
				style |= FontStyle.Italic;

			if (isUnderline)
				style |= FontStyle.Underline;

			richText_Top.Font = new Font(richText_Top.Font, style);
		}

		//ITALIC BUTTON
		private void italicButton_Click(object sender, EventArgs e) {
			isItalic = !isItalic;
			italicButton.Checked = isItalic;
			repaintTextBox();
		}

		//UNDERLINE BUTTON
		private void underlineButton_Click(object sender, EventArgs e) {
			isUnderline = !isUnderline;
			underlineButton.Checked = isUnderline;
			repaintTextBox();
		}

		//TEXT COLOR BUTTON
		private void textColor_but_Click(object sender, EventArgs e) {
			if(colorDialog.ShowDialog() == DialogResult.OK)  {  
				richText_Top.ForeColor = colorDialog.Color;  
			} 
		}

		//BACK COLOR BUTTON
		private void backColor_But_Click(object sender, EventArgs e) {
			if(colorDialog.ShowDialog() == DialogResult.OK)  {  
				richText_Top.BackColor = colorDialog.Color;  
			} 
		}

		//FONTS
		private void fontsComboBox_SelectedIndexChanged(object sender, EventArgs e) {
			richText_Top.Font = new Font(fontsComboBox.SelectedItem.ToString(), 12);
		}

		//DRAG & DROP
		private void listView1_DragDrop(object sender, DragEventArgs e) {
			string[] FileList = (string[])e.Data.GetData(DataFormats.FileDrop);

			string fileName = FileList[0];

			if (Path.GetExtension(fileName) != ".txt") {

			}
			else {
				System.IO.StreamReader sr = new   
					System.IO.StreamReader(fileName);

				listView1.Items.Clear();
				arrOfWords.Clear();

				//column headers
				var line = sr.ReadLine();
				var lineWords = line.Split(' ');
				while (!onlyLetters(lineWords[0], lineWords[1])) {
					line = sr.ReadLine();
					lineWords = line.Split(' ');
				}
				listView1.Columns[0].Text = lineWords[0];
				listView1.Columns[1].Text = lineWords[1];
				arrOfWords.Add(new data(lineWords[0], lineWords[1]));

				//listView
				while (!sr.EndOfStream)
				{
					line = sr.ReadLine();
					lineWords = line.Split(' ');
					while (!onlyLetters(lineWords[0], lineWords[1])) {
						line = sr.ReadLine();
						lineWords = line.Split(' ');
					}

					if (lineWords.Length != 2 || lineWords[0] == "" || lineWords[1]=="")
						continue;

					arrOfWords.Add(new data(lineWords[0], lineWords[1]));
					listView1.Items.Add(new ListViewItem(new [] {lineWords[0], lineWords[1]}));
				}

				sr.Close();  
			}
		}

		private void listView1_DragEnter(object sender, DragEventArgs e) {
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
				e.Effect = DragDropEffects.Copy;
		}
	}


	public class data {

		public data(string word1, string word2) {
			this.word1 = word1;
			this.word2 = word2;
		}

		public string word1;
		public string word2;
	}
}
