﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Translator {
	public partial class addWordForm : Form {
		private mainForm parentForm;
		
		public addWordForm(mainForm main) {
			InitializeComponent();
			parentForm = main;
		}

		public addWordForm(mainForm main, string word1) {
			InitializeComponent();
			parentForm = main;
			richTextBox1.Text = word1;
			richTextBox1.ReadOnly = true;
		}

		public void setLabels(string lb1, string lb2) {
			label1.Text = lb1;
			label2.Text = lb2;
		}

		public void DisactivateOwner() {
			this.Owner.Enabled = false;
		}

		private void cancel_but_Click(object sender, EventArgs e) {
			this.Owner.Enabled = true;
			this.Close();
		}

		private void add_but_Click(object sender, EventArgs e) {

			if (isProperWord(richTextBox1.Text) && isProperWord(richTextBox2.Text)) {

				parentForm.addWords(richTextBox1.Text, richTextBox2.Text);

				this.Owner.Enabled = true;
				this.Close();
			}
			else {
				validationErrForm childForm = new validationErrForm();
				childForm.Owner = this;
				this.Enabled = false;

				childForm.MaximizeBox = false;
				childForm.MinimizeBox = false;

				childForm.Location = new Point(
					(this.Location.X + this.Width / 2) - (childForm.Width / 2), 
					(this.Location.Y + this.Height / 2) - (childForm.Height / 2));

				childForm.Show();
			}
		}

		private void richTextBox1_Validating(object sender, CancelEventArgs e) {
			if (string.IsNullOrEmpty(richTextBox1.Text)) {
				errorProvider1.SetError(richTextBox1, "Cannot be empty!");
			}
			else if(hasNonLetter(richTextBox1.Text)){
				errorProvider1.SetError(richTextBox1, "Only letters are allowed!");
			}
			else {
				errorProvider1.SetError(richTextBox1, "");
			}
		}

		private void richTextBox2_Validating(object sender, CancelEventArgs e) {
			if (string.IsNullOrEmpty(richTextBox2.Text)) {
				errorProvider2.SetError(richTextBox2, "Cannot be empty!");
			}
			else if(hasNonLetter(richTextBox2.Text)){
				errorProvider2.SetError(richTextBox2, "Only letters are allowed!");
			}
			else {
				errorProvider1.SetError(richTextBox2, "");
			}
		}

		private bool hasNonLetter(string word) {
			foreach (var CHAR in word) {
				if (!char.IsLetter(CHAR))
					return true;
			}

			return false;
		}

		private void addWordForm_FormClosing(object sender, FormClosingEventArgs e) {
			Owner.Enabled = true;
		}

		private bool isProperWord(string word) {
			if (string.IsNullOrEmpty(word))
				return false;

			foreach (var CHAR in word) {
				if (!char.IsLetter(CHAR))
					return false;
			}

			return true;
		}
	}
}
