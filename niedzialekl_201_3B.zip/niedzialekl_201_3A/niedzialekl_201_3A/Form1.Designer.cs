﻿namespace niedzialekl_201_3A {
	partial class form_main {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if (disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_main));
			this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
			this.toolStrip1 = new System.Windows.Forms.ToolStrip();
			this.label_file = new System.Windows.Forms.ToolStripLabel();
			this.but_saveFile = new System.Windows.Forms.ToolStripButton();
			this.but_openFile = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
			this.label_tools = new System.Windows.Forms.ToolStripLabel();
			this.tool_brush = new System.Windows.Forms.ToolStripButton();
			this.tool_rectangle = new System.Windows.Forms.ToolStripButton();
			this.tool_ellipse = new System.Windows.Forms.ToolStripButton();
			this.tool_trash = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.label_thickness = new System.Windows.Forms.ToolStripLabel();
			this.comboBox_thickness = new System.Windows.Forms.ToolStripComboBox();
			this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
			this.label_choosenColor = new System.Windows.Forms.ToolStripLabel();
			this.but_choosenColor = new System.Windows.Forms.ToolStripButton();
			this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.but_English = new System.Windows.Forms.ToolStripButton();
			this.but_Polish = new System.Windows.Forms.ToolStripButton();
			this.toolStripContainer1.ContentPanel.SuspendLayout();
			this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
			this.toolStripContainer1.SuspendLayout();
			this.tableLayoutPanel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.groupBox1.SuspendLayout();
			this.toolStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// toolStripContainer1
			// 
			resources.ApplyResources(this.toolStripContainer1, "toolStripContainer1");
			// 
			// toolStripContainer1.BottomToolStripPanel
			// 
			resources.ApplyResources(this.toolStripContainer1.BottomToolStripPanel, "toolStripContainer1.BottomToolStripPanel");
			this.toolStripContainer1.BottomToolStripPanelVisible = false;
			// 
			// toolStripContainer1.ContentPanel
			// 
			resources.ApplyResources(this.toolStripContainer1.ContentPanel, "toolStripContainer1.ContentPanel");
			this.toolStripContainer1.ContentPanel.Controls.Add(this.tableLayoutPanel1);
			// 
			// toolStripContainer1.LeftToolStripPanel
			// 
			resources.ApplyResources(this.toolStripContainer1.LeftToolStripPanel, "toolStripContainer1.LeftToolStripPanel");
			this.toolStripContainer1.LeftToolStripPanelVisible = false;
			this.toolStripContainer1.Name = "toolStripContainer1";
			// 
			// toolStripContainer1.RightToolStripPanel
			// 
			resources.ApplyResources(this.toolStripContainer1.RightToolStripPanel, "toolStripContainer1.RightToolStripPanel");
			this.toolStripContainer1.RightToolStripPanelVisible = false;
			// 
			// toolStripContainer1.TopToolStripPanel
			// 
			resources.ApplyResources(this.toolStripContainer1.TopToolStripPanel, "toolStripContainer1.TopToolStripPanel");
			this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.toolStrip1);
			// 
			// tableLayoutPanel1
			// 
			resources.ApplyResources(this.tableLayoutPanel1, "tableLayoutPanel1");
			this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.groupBox1, 1, 0);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			// 
			// pictureBox1
			// 
			resources.ApplyResources(this.pictureBox1, "pictureBox1");
			this.pictureBox1.BackColor = System.Drawing.Color.White;
			this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Cross;
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.TabStop = false;
			this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
			this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
			this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
			// 
			// groupBox1
			// 
			resources.ApplyResources(this.groupBox1, "groupBox1");
			this.groupBox1.Controls.Add(this.flowLayoutPanel1);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.TabStop = false;
			// 
			// flowLayoutPanel1
			// 
			resources.ApplyResources(this.flowLayoutPanel1, "flowLayoutPanel1");
			this.flowLayoutPanel1.Name = "flowLayoutPanel1";
			// 
			// toolStrip1
			// 
			resources.ApplyResources(this.toolStrip1, "toolStrip1");
			this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
			this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.label_file,
            this.but_saveFile,
            this.but_openFile,
            this.toolStripSeparator3,
            this.label_tools,
            this.tool_brush,
            this.tool_rectangle,
            this.tool_ellipse,
            this.tool_trash,
            this.toolStripSeparator1,
            this.label_thickness,
            this.comboBox_thickness,
            this.toolStripSeparator4,
            this.label_choosenColor,
            this.but_choosenColor,
            this.toolStripSeparator2,
            this.but_English,
            this.but_Polish});
			this.toolStrip1.Name = "toolStrip1";
			// 
			// label_file
			// 
			resources.ApplyResources(this.label_file, "label_file");
			this.label_file.Name = "label_file";
			// 
			// but_saveFile
			// 
			resources.ApplyResources(this.but_saveFile, "but_saveFile");
			this.but_saveFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.but_saveFile.Image = global::niedzialekl_201_3A.Properties.Resources.save;
			this.but_saveFile.Name = "but_saveFile";
			this.but_saveFile.Click += new System.EventHandler(this.but_saveFile_Click);
			// 
			// but_openFile
			// 
			resources.ApplyResources(this.but_openFile, "but_openFile");
			this.but_openFile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.but_openFile.Image = global::niedzialekl_201_3A.Properties.Resources.load;
			this.but_openFile.Name = "but_openFile";
			this.but_openFile.Click += new System.EventHandler(this.but_openFile_Click);
			// 
			// toolStripSeparator3
			// 
			resources.ApplyResources(this.toolStripSeparator3, "toolStripSeparator3");
			this.toolStripSeparator3.Name = "toolStripSeparator3";
			// 
			// label_tools
			// 
			resources.ApplyResources(this.label_tools, "label_tools");
			this.label_tools.Name = "label_tools";
			// 
			// tool_brush
			// 
			resources.ApplyResources(this.tool_brush, "tool_brush");
			this.tool_brush.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.tool_brush.Image = global::niedzialekl_201_3A.Properties.Resources.brush;
			this.tool_brush.Name = "tool_brush";
			this.tool_brush.Click += new System.EventHandler(this.tool_brush_Click);
			// 
			// tool_rectangle
			// 
			resources.ApplyResources(this.tool_rectangle, "tool_rectangle");
			this.tool_rectangle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.tool_rectangle.Image = global::niedzialekl_201_3A.Properties.Resources.rect;
			this.tool_rectangle.Name = "tool_rectangle";
			this.tool_rectangle.Click += new System.EventHandler(this.tool_rectangle_Click);
			// 
			// tool_ellipse
			// 
			resources.ApplyResources(this.tool_ellipse, "tool_ellipse");
			this.tool_ellipse.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.tool_ellipse.Image = global::niedzialekl_201_3A.Properties.Resources.ellipse;
			this.tool_ellipse.Name = "tool_ellipse";
			this.tool_ellipse.Click += new System.EventHandler(this.tool_ellipse_Click);
			// 
			// tool_trash
			// 
			resources.ApplyResources(this.tool_trash, "tool_trash");
			this.tool_trash.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.tool_trash.Image = global::niedzialekl_201_3A.Properties.Resources.trash;
			this.tool_trash.Name = "tool_trash";
			this.tool_trash.Click += new System.EventHandler(this.tool_trash_Click);
			// 
			// toolStripSeparator1
			// 
			resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
			this.toolStripSeparator1.Name = "toolStripSeparator1";
			// 
			// label_thickness
			// 
			resources.ApplyResources(this.label_thickness, "label_thickness");
			this.label_thickness.Name = "label_thickness";
			// 
			// comboBox_thickness
			// 
			resources.ApplyResources(this.comboBox_thickness, "comboBox_thickness");
			this.comboBox_thickness.Name = "comboBox_thickness";
			this.comboBox_thickness.SelectedIndexChanged += new System.EventHandler(this.comboBox_thickness_SelectedIndexChanged);
			// 
			// toolStripSeparator4
			// 
			resources.ApplyResources(this.toolStripSeparator4, "toolStripSeparator4");
			this.toolStripSeparator4.Name = "toolStripSeparator4";
			// 
			// label_choosenColor
			// 
			resources.ApplyResources(this.label_choosenColor, "label_choosenColor");
			this.label_choosenColor.Name = "label_choosenColor";
			// 
			// but_choosenColor
			// 
			resources.ApplyResources(this.but_choosenColor, "but_choosenColor");
			this.but_choosenColor.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.but_choosenColor.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
			this.but_choosenColor.Name = "but_choosenColor";
			// 
			// toolStripSeparator2
			// 
			resources.ApplyResources(this.toolStripSeparator2, "toolStripSeparator2");
			this.toolStripSeparator2.Name = "toolStripSeparator2";
			// 
			// but_English
			// 
			resources.ApplyResources(this.but_English, "but_English");
			this.but_English.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.but_English.Image = global::niedzialekl_201_3A.Properties.Resources.flag_gb;
			this.but_English.Name = "but_English";
			this.but_English.Click += new System.EventHandler(this.changeLanguage_Click);
			// 
			// but_Polish
			// 
			resources.ApplyResources(this.but_Polish, "but_Polish");
			this.but_Polish.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.but_Polish.Image = global::niedzialekl_201_3A.Properties.Resources.flag_pl;
			this.but_Polish.Name = "but_Polish";
			this.but_Polish.Click += new System.EventHandler(this.changeLanguage_Click);
			// 
			// form_main
			// 
			resources.ApplyResources(this, "$this");
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.toolStripContainer1);
			this.Name = "form_main";
			this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
			this.toolStripContainer1.ContentPanel.ResumeLayout(false);
			this.toolStripContainer1.ContentPanel.PerformLayout();
			this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
			this.toolStripContainer1.TopToolStripPanel.PerformLayout();
			this.toolStripContainer1.ResumeLayout(false);
			this.toolStripContainer1.PerformLayout();
			this.tableLayoutPanel1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.toolStrip1.ResumeLayout(false);
			this.toolStrip1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.ToolStripContainer toolStripContainer1;
		private System.Windows.Forms.ToolStrip toolStrip1;
		private System.Windows.Forms.ToolStripLabel label_tools;
		private System.Windows.Forms.ToolStripButton tool_brush;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
		private System.Windows.Forms.ToolStripButton but_choosenColor;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
		private System.Windows.Forms.ToolStripButton but_saveFile;
		private System.Windows.Forms.ToolStripButton but_openFile;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
		private System.Windows.Forms.ToolStripLabel label_file;
		private System.Windows.Forms.ToolStripLabel label_choosenColor;
		private System.Windows.Forms.ToolStripButton tool_rectangle;
		private System.Windows.Forms.ToolStripButton tool_trash;
		private System.Windows.Forms.ToolStripButton tool_ellipse;
		private System.Windows.Forms.ToolStripLabel label_thickness;
		private System.Windows.Forms.ToolStripComboBox comboBox_thickness;
		private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
		private System.Windows.Forms.ToolStripButton but_English;
		private System.Windows.Forms.ToolStripButton but_Polish;
	}
}

