﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace niedzialekl_201_3A {
	public partial class form_main : Form {

		private bool isBrushActive = false;
		private bool isEllipseActive = false;
		private bool isRectangleActive = false;
		private bool isDrawing = false;
		private Pen pen;
		private Bitmap bmp;
		private Point? prevPoint;
		private string initDir = "C:\\Users\\genix\\Desktop\\IMAGES";

		public form_main() {
			InitializeComponent();
			pen = new Pen(Color.Black, 1);
			addColors();
			addThicknesses(3);
			CultureInfo.CurrentUICulture = CultureInfo.CreateSpecificCulture("en");
			localize();
			but_English.Checked = true;
		}

		//LOCALIZE
		private void localize() {
			Assembly a = Assembly.Load("niedzialekl_201_3A");
			ResourceManager rm = new ResourceManager("niedzialekl_201_3A.GlobalStrings", a);

			label_file.Text = rm.GetString("label_file_Text");
			but_saveFile.Text = rm.GetString("but_saveFile_Text");
			but_openFile.Text = rm.GetString("but_openFile_Text");
			label_tools.Text = rm.GetString("label_tools_Text");
			tool_brush.Text = rm.GetString("tool_brush_Text");
			tool_rectangle.Text = rm.GetString("tool_rectangle_Text");
			tool_ellipse.Text = rm.GetString("tool_ellipse_Text");
			tool_trash.Text = rm.GetString("tool_trash_Text");
			label_thickness.Text = rm.GetString("label_thickness_Text");
			label_choosenColor.Text = rm.GetString("label_choosenColor_Text");
			but_choosenColor.Text = rm.GetString("but_choosenColor_Text");
			groupBox1.Text = rm.GetString("groupBox1_Text");
			but_English.Text = rm.GetString("but_English_Text");
			but_Polish.Text = rm.GetString("but_Polish_Text");
		}

		//THICKNESSES
		private void addThicknesses(int n) {
			for (int i = 0; i < n; i++) {
				comboBox_thickness.Items.Add(i + 1);
			}

			comboBox_thickness.SelectedIndex = (int) pen.Width - 1;
		}

		//COLORS
		public void addColors() {
			KnownColor[] values = (KnownColor[]) Enum.GetValues(typeof(KnownColor));
			foreach (var color in values) {
				Button newBut = new Button();
				newBut.BackColor = Color.FromKnownColor(color);
				newBut.Size = new Size(25,25);
				newBut.FlatStyle = FlatStyle.Flat;
				newBut.FlatAppearance.BorderSize = 0;
				newBut.FlatAppearance.MouseOverBackColor = newBut.BackColor;
				newBut.FlatAppearance.MouseDownBackColor = newBut.BackColor;
				newBut.Click += (object sender, EventArgs e) => {
					//color button
					but_choosenColor.BackColor = newBut.BackColor;
					//remove existing border
					foreach(Button but in flowLayoutPanel1.Controls) {
						if(but.BackColor == pen.Color) {
							Graphics g1 = but.CreateGraphics();
							g1.Clear(pen.Color);
							g1.Dispose();
							break;
						}
					}
					//color pen
					pen = new Pen(newBut.BackColor, pen.Width);
					//create border
					Pen tempPen = new Pen(Color.FromArgb(newBut.BackColor.ToArgb() ^ 0xffffff), 3);
					tempPen.DashStyle = DashStyle.Dot;
					Graphics g = newBut.CreateGraphics();
					Rectangle rec = newBut.ClientRectangle;
					rec.Width = rec.Width - 1;
					rec.Height = rec.Height - 1;
					g.DrawRectangle(tempPen, rec);
				};
				newBut.Paint += (object sender, PaintEventArgs e) => {
					if (newBut.BackColor == pen.Color) {
						Pen tempPen = new Pen(Color.FromArgb(newBut.BackColor.ToArgb() ^ 0xffffff), 3);
						tempPen.DashStyle = DashStyle.Dot;
						Rectangle rec = newBut.ClientRectangle;
						rec.Width = rec.Width - 1;
						rec.Height = rec.Height - 1;
						e.Graphics.DrawRectangle(tempPen, rec);
					}
					else {
						e.Graphics.Clear(newBut.BackColor);
					}
				};

				flowLayoutPanel1.Controls.Add(newBut);
			}
		}

		//BRUSH BUTTON
		private void tool_brush_Click(object sender, EventArgs e) {
			isBrushActive = !isBrushActive;
			tool_brush.Checked = isBrushActive;

			isRectangleActive = false;
			tool_rectangle.Checked = false;

			isEllipseActive = false;
			tool_ellipse.Checked = false;
		}

		//RECTANGLE BUTTON
		private void tool_rectangle_Click(object sender, EventArgs e) {
			isBrushActive = false;
			tool_brush.Checked = false;

			isRectangleActive = !isRectangleActive;
			tool_rectangle.Checked = isRectangleActive;

			isEllipseActive = false;
			tool_ellipse.Checked = false;
		}

		//ELLIPSE BUTTON
		private void tool_ellipse_Click(object sender, EventArgs e) {
			isBrushActive = false;
			tool_brush.Checked = false;

			isRectangleActive = false;
			tool_rectangle.Checked = false;

			isEllipseActive = !isEllipseActive;
			tool_ellipse.Checked = isEllipseActive;
		}

		//MOUSE DOWN
		private void pictureBox1_MouseDown(object sender, MouseEventArgs e) {
			if (e.Button == MouseButtons.Right)
				isDrawing = false;
			else
				isDrawing = true;

			prevPoint = e.Location;
		}

		//MOUSE UP
		private void pictureBox1_MouseUp(object sender, MouseEventArgs e) {
			if (e.Button == MouseButtons.Right)
				pictureBox1.Image = bmp;
			else
				bmp = new Bitmap(pictureBox1.Image);

			isDrawing = false;
		}

		//MOUSE MOVE
		private void pictureBox1_MouseMove(object sender, MouseEventArgs e) {
			if (pictureBox1.Image == null) {
				bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
				using (Graphics g = Graphics.FromImage(bmp)) {
					g.Clear(Color.White);
				}

				pictureBox1.Image = bmp;
			}

			if (isDrawing) {
				if(isBrushActive)
					drawLine(sender, e);
				if(isEllipseActive)
					drawEllipse(sender, e);
				if(isRectangleActive)
					drawRectangle(sender, e);
			}
		}

		//DRAWINGS
		private void drawLine(object sender, MouseEventArgs e) {
			if (prevPoint != null) {

				using (Graphics g = Graphics.FromImage(pictureBox1.Image)) {
					g.DrawLine(pen, prevPoint.Value, e.Location);
				}

				pictureBox1.Invalidate();
				prevPoint = e.Location;
			}
		}

		private void drawRectangle(object sender, MouseEventArgs e) {
			if (prevPoint != null) {

				Bitmap tempBmp = new Bitmap(bmp);
				Graphics g = Graphics.FromImage(tempBmp);
				int startX = Math.Min(prevPoint.Value.X, e.X);
				int startY = Math.Min(prevPoint.Value.Y, e.Y);
				int width = Math.Abs(prevPoint.Value.X - e.X);
				int height = Math.Abs(prevPoint.Value.Y - e.Y);

				g.DrawRectangle(pen,
					startX,
					startY,
					width,
					height);

				pictureBox1.Image = tempBmp;
				pictureBox1.Refresh();
			}
		}

		private void drawEllipse(object sender, MouseEventArgs e) {
			if (prevPoint != null) {

				Bitmap tempBmp = new Bitmap(bmp);
				Graphics g = Graphics.FromImage(tempBmp);
				int startX = Math.Min(prevPoint.Value.X, e.X);
				int startY = Math.Min(prevPoint.Value.Y, e.Y);
				int width = Math.Abs(prevPoint.Value.X - e.X);
				int height = Math.Abs(prevPoint.Value.Y - e.Y);

				g.DrawEllipse(pen,
					startX,
					startY,
					width,
					height);

				pictureBox1.Image = tempBmp;
				pictureBox1.Refresh();
			}
		}

		//CHANGE SIZE
		private void Form1_SizeChanged(object sender, EventArgs e) {
			if (bmp != null) {
				Bitmap newbitmap = new Bitmap(pictureBox1.Size.Width, pictureBox1.Size.Height);
				Graphics g = Graphics.FromImage(newbitmap);
				g.Clear(Color.White);
				g.DrawImageUnscaled(bmp, 0, 0);
				bmp = newbitmap;
				pictureBox1.Image = bmp;
				pictureBox1.Refresh();
				pictureBox1.Refresh();

			}

			flowLayoutPanel1.Refresh();
		}

		//SAVE FILE
		private void but_saveFile_Click(object sender, EventArgs e) {
			SaveFileDialog dialog = new SaveFileDialog();
			dialog.Filter = "Bitmap Image (*.bmp)|*.bmp|JPEG Image (*.jpeg)|*.jpeg|PNG Image (*.png)|*.png";
			dialog.FilterIndex = 1;
			dialog.InitialDirectory = initDir;
			if (dialog.ShowDialog() == DialogResult.OK) {
				ImageFormat format;

				if(dialog.FilterIndex == 1)
					format = ImageFormat.Bmp;
				else if(dialog.FilterIndex == 2)
					format = ImageFormat.Jpeg;
				else
					format = ImageFormat.Png;

				Bitmap temp = bmp;
				bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
				using (Graphics grfx = Graphics.FromImage(bmp)) {
					grfx.Clear(Color.White);
					grfx.DrawImage(temp, 0, 0);
				}
				bmp.Save(dialog.FileName, format);
			}
		}

		//OPEN FILE
		private void but_openFile_Click(object sender, EventArgs e) {
			OpenFileDialog dialog = new OpenFileDialog();
			dialog.Filter = "Bitmap Image (*.bmp)|*.bmp|JPEG Image (*.jpeg)|*.jpeg|PNG Image (*.png)|*.png";
			dialog.FilterIndex = 2;
			dialog.InitialDirectory = initDir;

			if (dialog.ShowDialog() == DialogResult.OK) {

				if (bmp == null) {
					bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
				}

				Bitmap tempBmp = new Bitmap(dialog.FileName);

				Size diff = tempBmp.Size - bmp.Size;
				bmp = tempBmp;
				pictureBox1.Size = bmp.Size;
				tempBmp = new Bitmap(tempBmp, bmp.Width, bmp.Height);
				bmp = tempBmp;
				pictureBox1.Image = bmp;
				pictureBox1.Refresh();

				Size += diff;
				Invalidate();


				flowLayoutPanel1.Refresh();
			}
		}

		//CREAR
		private void tool_trash_Click(object sender, EventArgs e) {
			bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
			Graphics g = Graphics.FromImage(bmp);
			g.Clear(Color.White);
			pictureBox1.Image = bmp;
		}

		//CHANGE THICKNESS
		private void comboBox_thickness_SelectedIndexChanged(object sender, EventArgs e) {
			pen = new Pen(pen.Color, comboBox_thickness.SelectedIndex + 1);
		}

		//CHANGE LANGUAGE
		private void changeLanguage_Click(object sender, EventArgs e) {
			if (sender == but_English) {
				CultureInfo.CurrentUICulture = CultureInfo.CreateSpecificCulture("en");
				localize();
				but_English.Checked = true;
				but_Polish.Checked = false;
			}
			else {
				
				CultureInfo.CurrentUICulture = CultureInfo.CreateSpecificCulture("pl");
				localize();
				but_English.Checked = false;
				but_Polish.Checked = true;
			}
//			this.Hide();
//			System.Threading.Thread.Sleep(500);
//			this.Show();
		}
	}
}
